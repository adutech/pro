<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title></title>
<meta name="keyword" content="">
<meta name="description" content="">
<meta name="author" content="chandan Parmar">
<meta http-equiv="refresh" content="160"> 
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<script type="text/javascript" src="assets/js/popper.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
</head>
<body>
<main>


<div class="container-fluid">
  <div class="row border-btn-nav">
  <div class="col-sm-3 col-5">

    <span style="font-size:23px;cursor:pointer; font-weight: 600;" onclick="openNav()">&#9776; sqrlly</span>
    <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>
  </div>
   <div class="col-sm-6 col-7">
   <form>
     <div class="form">
       <div class="form-group">
         <input type="search" name="search here" class="form-control" placeholder="search by category" style="width:70%; margin:5px 10px; background-color: #f4f4f4;">
       </div>
     </div>
   </form>
  </div>

  <div class="col-sm-3 col-12">
   <ul class="list-group list-group-horizontal">
  <li class="list-group-item"><a class="btn btn-primary user-name">chandan</a></li>
  <li class="list-group-item"><i class="fa fa-user-o user-icon"></i></li>
  <li class="list-group-item"><span class="badge badge-danger">2</span></li>
  
</ul>
  </div>
  </div>
</div>
</div>



<style type="text/css">

  .badge {
    display: inline-block;
    padding: 0.25em 0.4em;
    font-size: 100%;
    font-weight: 700;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.25rem;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
 .user-icon {
    font-size: 27px;
}
  .user-name{
    color:#fff !important;
    border-radius: 20px;
    font-size: 12px;
  }
  .list-group-item {
    position: relative;
    display: block;
    padding: 0.75rem 1.25rem;
    background-color: #fff;
    border:none;
}

.user-icon {
    border-radius: 100%;
    background: #f4f4f4;
    font-size: 18px;
    padding: 6px;
}
</style>
