<?php include('header.php');?>
<section class="section-breadcrumb-1">
<div class="container-fluid">
  <div class="row">
  <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-angle-left"></i> Home</li>
  </ol>
</nav>
</div>
</div>
</section>
<!--------Breadcrumb End--------->
<section class="section-page-1" style="background-image: url(assets/img/bg.jpg); background-attachment:fixed; background-size: 100% 100%;">
<div class="container-fluid">

<div class="row">
<div class="col-sm-8 mar-20">
  <div class="row">
    <div class="col-sm-3">
    <div class="sec-1">
      
    </div>
    </div>
        <div class="col-sm-6">
          <div class="row product-tiltle">
          <div class="col-12">
          
          <h5>ridegreen Zoon</h5>
          <a href="#" class="btn btn-primary">e-bicyles</a>
            
        </div>
        </div>
           <div class="row price-sec">
           <div class="col-6">
          <h2>Rs. 230</h2>
          
            </div>
          <div class="col-6">
          
          <a href="#" class="btn btn-primary">Test Ride Now</a>
            </div>
        </div>
        </div>
        <div class="col-sm-3">
    <ul class="list-group list-group-flush bg-grey">
  <li class="list-group-item"><i class="fa fa-heart"></i> make as a favourite</li>
  <li class="list-group-item"><i class="fa fa-plus"></i> add to Compare</li>
</ul>
    </div>
  </div>

<div class="row">
   
        <div class="table-responsive" style="padding: 10px;">
      <table class="table table-borderless">
  
  <tbody>
    <tr>
      <td><span style="color: blue; font-weight: 600; ">Range</span><br>70km</td>
      <td><span style="color: blue; font-weight: 600; ">Top Speed</span><br>25km/h</td>
    </tr>
    <br>
    <br>
    <tr>
       <td><span style="color: blue; font-weight: 600; ">Seating Capacity</span><br>1Adult & 1kid</td>
      <td><span style="color: blue; font-weight: 600; ">OEM</span><br>Mahindra System</td>
    </tr>
   
  </tbody>
</table>
      </div>
</div>

<div class="row product-section">
                    <div class="col-8">
                        <div class="section-title  text-left">
                            <h5 class="float-left" style="color:#b56c40; font-weight: 600;">Similar e-bicyles</h5>
                     </div>
                    </div>
           <div class="col-4">
                     <a href="#" class="btn btn-sucess float-right">View All <i class="fa fa-angle-right"></i></a>
                   </div>
                </div>
  <div class="row">
    <div class="col-sm-4">
      <div class="sec-1 bg-blue">
      
    </div>
    </div>
    <div class="col-sm-4">
      <div class="sec-1 bg-blue">
      
    </div>
    </div>
    <div class="col-sm-4">
      <div class="sec-1 bg-blue">
      
    </div>
    </div>

  </div>
</div>


<div class="col-sm-4 border-right-side cstm">
  <div class="section-style mar-20">
  <div class="row sec-3">
                    <div class="col-8">
                        <div class="section-title text-left">
                            <h5 class="float-left">Subscription Plan</h5>
                     </div>
                    </div>
           <div class="col-4">
                     <a href="#" class="float-right">Know more</a>
                   </div>
                </div>
                <div class="row price-sec">
                    <div class="col-4">
                     <a href="#" class="btn btn__bg ">1 month</a>
                     <h2>Rs. 230</h2>
                   </div>
           <div class="col-4">
                     <a href="#" class="btn btn__bg ">2 months</a>
                     <h2>Rs. 230</h2>
                   </div>
                   <div class="col-4">

                     <a href="#" class="btn btn__bg ">3 months</a>
                     <h2>Rs. 230</h2>
                   </div>
                </div>
            </div>
                <div class="row">
                  <div class="col-12">
                  <div class="heading-title">
                    <h2>Specaheet for nerds</h2>
                  </div>
                </div>
            </div>
           


           <div class="row">


    <div class="col-md-12">
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-warning">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
         Dimension
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="">
      <div class="panel-body">
        <div class="table-responsive">
      <table class="table table-borderless">
  
  <tbody>
    <tr>
     
      <td>Range</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jacob</td>
     
    </tr>
   
  </tbody>
</table>
      </div>
      </div>
    </div>
  </div>
  <div class="panel panel-warning">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
         suspension Break and Steering
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
      <div class="panel-body">
  <div class="table-responsive">
      <table class="table table-borderless">
  
  <tbody>
    <tr>
     
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jacob</td>
     
    </tr>
   
  </tbody>
</table>
      </div>
      </div>
    </div>
  </div>
  <div class="panel panel-warning">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Capacity
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" aria-expanded="false">
      <div class="panel-body">
  <div class="table-responsive">
      <table class="table table-borderless">
  
  <tbody>
    <tr>
     
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jacob</td>
     
    </tr>
   
  </tbody>
</table>
      </div>
      </div>
    </div>
  </div>
  
  
  
  
  
  <div class="panel panel-warning">
    <div class="panel-heading" role="tab" id="headingfour">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
          Motor And Controler
        </a>
      </h4>
    </div>
    <div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfour" aria-expanded="false">
      <div class="panel-body">
        <div class="table-responsive">
      <table class="table table-borderless">
  
  <tbody>
    <tr>
     
      <td>Range</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jacob</td>
     
    </tr>
   
  </tbody>
</table>
      </div>
    </div>
  </div>
 


  
  </div>
</div>
</div>
</div>



</div>
</section>


<?php include('footer.php');?>
